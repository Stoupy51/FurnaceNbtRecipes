
#> furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_all
#
# @executed	as the player & at current position
#
# @within	furnace_nbt_recipes:v1.10.2/advancements/placed_furnace
#

# Look at where the block has been placed
execute positioned ~ ~8 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~7 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~6 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~5 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~4 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~3 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~2 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~1 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~-1 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~-2 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~-3 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~-4 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~-5 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~-6 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~-7 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer
execute positioned ~ ~-8 ~ run function furnace_nbt_recipes:v1.10.2/advancements/check_for_furnaces/look_layer

