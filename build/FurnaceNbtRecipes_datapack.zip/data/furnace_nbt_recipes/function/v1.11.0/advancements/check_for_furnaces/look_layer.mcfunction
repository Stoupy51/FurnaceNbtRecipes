
#> furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_layer
#
# @executed	positioned ~ ~8 ~
#
# @within	furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~8 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~7 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~6 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~5 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~4 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~3 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~2 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~1 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~-1 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~-2 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~-3 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~-4 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~-5 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~-6 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~-7 ~ ]
#			furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/look_all [ positioned ~ ~-8 ~ ]
#

# Look at where the block has been placed
execute positioned ~-8 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-8 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~-7 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-7 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~-6 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-6 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~-5 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-5 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~-4 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-4 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~-3 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-3 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~-2 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-2 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~-1 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~-1 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~0 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~0 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~8 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~8 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~7 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~7 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~6 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~6 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~5 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~5 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~4 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~4 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~3 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~3 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~2 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~2 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

execute positioned ~1 ~ ~-8 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~-7 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~-6 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~-5 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~-4 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~-3 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~-2 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~-1 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~00 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~01 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~02 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~03 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~04 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~05 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~06 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~07 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker
execute positioned ~1 ~ ~08 if block ~ ~ ~ #furnace_nbt_recipes:furnaces run function furnace_nbt_recipes:v1.11.0/advancements/check_for_furnaces/try_place_marker

